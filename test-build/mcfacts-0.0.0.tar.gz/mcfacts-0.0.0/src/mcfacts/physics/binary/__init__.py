"""
Module for handling the evolution, formation, and merging of binaries.
"""
