"""
Underlying methods used to create and/or evolve physical systems in McFACTS simulations.
"""
