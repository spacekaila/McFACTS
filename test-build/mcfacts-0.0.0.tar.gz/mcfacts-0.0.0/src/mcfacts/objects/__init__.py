"""
Object structures used in McFACTS
"""
