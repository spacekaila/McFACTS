"""
Objects and methods for handling data input for McFACTS simulations.
"""
