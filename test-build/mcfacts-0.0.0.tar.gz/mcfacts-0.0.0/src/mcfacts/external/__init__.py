"""
External and third-party objects or methods used in McFACTS.
"""
