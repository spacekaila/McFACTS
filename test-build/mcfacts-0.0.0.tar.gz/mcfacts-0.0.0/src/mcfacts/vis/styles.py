
# Colors
color_gen1 = "darkgoldenrod"
color_gen2 = "rebeccapurple"
color_genX = "red"
color_line1 = "teal"

# Marker Styles
marker_gen1 = 'o'
marker_gen2 = 'v'
marker_genX = '^'

# Marker Size
markersize_gen1 = 10
markersize_gen2 = 10
markersize_genX = 10

# Marker transperancy
markeralpha_gen1 = 0.6
markeralpha_gen2 = 0.6
markeralpha_genX = 0.6
