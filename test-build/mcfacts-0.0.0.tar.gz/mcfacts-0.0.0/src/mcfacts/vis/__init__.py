"""
Internal and third-party utility code to aid in the creation of plots and other metrics.
"""
