"""
Methods for creating and instantiating arrays and objects used in McFACTS simulations.
"""
