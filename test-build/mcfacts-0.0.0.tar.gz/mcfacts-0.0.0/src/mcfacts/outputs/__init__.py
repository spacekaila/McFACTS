"""
Objects and methods for handling file output for McFACTS simulations.
"""
